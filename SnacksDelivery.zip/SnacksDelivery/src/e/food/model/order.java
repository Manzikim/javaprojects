/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e.food.model;

/**
 *
 * @author User
 */
public class order {
    
    private String orderNo;
    private String time;
    private String client;
    private String resto;
    private String Menu;
    private String trans;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getResto() {
        return resto;
    }

    public void setResto(String resto) {
        this.resto = resto;
    }

    public String getMenu() {
        return Menu;
    }

    public void setMenu(String Menu) {
        this.Menu = Menu;
    }

    public String getTrans() {
        return trans;
    }

    public void setTrans(String trans) {
        this.trans = trans;
    }

    public order(String orderNo, String time, String client, String resto, String Menu, String trans) {
        this.orderNo = orderNo;
        this.time = time;
        this.client = client;
        this.resto = resto;
        this.Menu = Menu;
        this.trans = trans;
    }

    
}
