/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e.food.model;

/**
 *
 * @author NIC
 */
public class assignM {
    private String Oid;
    private String transporter;
    private String date;

    public String getOid() {
        return Oid;
    }

    public void setOid(String Oid) {
        this.Oid = Oid;
    }

    public String getTransporter() {
        return transporter;
    }

    public void setTransporter(String transporter) {
        this.transporter = transporter;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public assignM() {
    }

    public assignM(String Oid, String transporter, String date) {
        this.Oid = Oid;
        this.transporter = transporter;
        this.date = date;
    }

   
   
    
}
