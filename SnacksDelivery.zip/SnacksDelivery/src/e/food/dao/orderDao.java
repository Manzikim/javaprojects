/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e.food.dao;



import e.food.model.order;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class orderDao {
    public int createOrder(order ord) {
        
     Connection con = null;
        try {
            String sql ="INSERT INTO torder VALUES(?,?,?,?,?,?)";
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/fd","postgres","123456");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, ord.getOrderNo());
            pst.setString(2, ord.getTime());
            pst.setString(3, ord.getClient().toString());
            pst.setString(4, ord.getResto().toString());
            pst.setString(5, ord.getMenu().toString());
            pst.setString(6, ord.getTrans().toString());
            
            
            pst.executeUpdate();
          return 1;  
        
            
            
        } catch (SQLException ex) {
            Logger.getLogger(orderDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
        

 }
    public ArrayList<order> getOrder() {
        String sql = "select * from torder";
        String url = "jdbc:postgresql://localhost:5432/fd";
        String username = "postgres";
        String password = "123456";
        ArrayList<order> list = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                order model = new order(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
                list.add(model);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;

    }
    
    public int deleteOrder(String id) {
        String sql = "delete from torder where orderNo=?";
        String url = "jdbc:postgresql://localhost:5432/fd";
        String username = "postgres";
        String password = "123456";
        int row = 0;
        try {
            Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, id);
            row = pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }
    
    public int updateOrder(order resto){
        Connection con = null;
        try {
            String sql ="UPDATE torder SET time=?,client=?,resto=?,menu=?,transport=? WHERE orderno=?";
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/fd","postgres","123456");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, resto.getTime());
            pst.setString(2, resto.getClient());
            pst.setString(3, resto.getResto());
            pst.setString(4, resto.getMenu());
            pst.setString(5, resto.getTrans());
            pst.setString(6, resto.getOrderNo());
            pst.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            Logger.getLogger(orderDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (con != null){
                try {   
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(orderDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        }
    return 0;
    }
}
