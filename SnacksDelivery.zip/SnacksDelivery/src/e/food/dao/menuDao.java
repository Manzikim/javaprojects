/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e.food.dao;

import e.food.model.menu;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class menuDao {
   public int createMenu(menu mn) {
        
     Connection con = null;
        try {
            String sql ="INSERT INTO menu VALUES(?,?,?)";
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/fd","postgres","123456");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, mn.getName());
            pst.setString(2, mn.getDescription());
            pst.setString(3, mn.getItems().toString());
            pst.executeUpdate();
          return 1;  
        
            
            
        } catch (SQLException ex) {
            Logger.getLogger(menuDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
        

 }
   
   public ArrayList<menu> getMenu() {
        String sql = "select * from menu";
        String url = "jdbc:postgresql://localhost:5432/fd";
        String username = "postgres";
        String password = "123456";
        ArrayList<menu> list = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                menu model = new menu(rs.getString(1), rs.getString(2), rs.getString(3));
                list.add(model);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;

    }
   
   public int deleteMenu(String Mname) {
        String sql = "delete from menu where name=?";
        String url = "jdbc:postgresql://localhost:5432/fd";
        String username = "postgres";
        String password = "123456";
        int row = 0;
        try {
            Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, Mname);
            row = pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }
}
