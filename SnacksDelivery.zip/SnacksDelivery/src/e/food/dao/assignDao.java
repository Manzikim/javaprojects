/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e.food.dao;

import e.food.model.assignM;
import e.food.model.transp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author NIC
 */
public class assignDao {
    public int createAssign(assignM ass) {
        
     Connection con = null;
        try {
            String sql ="INSERT INTO assign VALUES(?,?,?)";
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/fd","postgres","123456");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, ass.getOid());
            pst.setString(2, ass.getTransporter());
            pst.setString(3, ass.getDate());
            
            
            
            pst.executeUpdate();
          return 1;  
        
            
            
        } catch (SQLException ex) {
            Logger.getLogger(transp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
        

 }
    
}
