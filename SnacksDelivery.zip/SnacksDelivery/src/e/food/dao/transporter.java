/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e.food.dao;


import e.food.model.transp;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class transporter {
    public int createtrans(transp trs) {
        
     Connection con = null;
        try {
            String sql ="INSERT INTO transport VALUES(?,?,?,?)";
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/fd","postgres","123456");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, trs.getName());
            pst.setString(2, trs.getCategory().toString());
            pst.setString(3, trs.getPhone_number());
            pst.setString(4, trs.getEmail());
            
            
            
            pst.executeUpdate();
          return 1;  
        
            
            
        } catch (SQLException ex) {
            Logger.getLogger(transp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
        

 }
    
    public int updatetransp(transp resto){
        Connection con = null;
        try {
            String sql ="UPDATE transport SET category=?,phone=?,email=? WHERE name=?";
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/fd","postgres","123456");
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(4, resto.getName());
            pst.setString(1, resto.getCategory().toString());
            pst.setString(2, resto.getPhone_number());
            pst.setString(3, resto.getEmail());
            
            pst.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            Logger.getLogger(transporter.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (con != null){
                try {   
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(transporter.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        }
    return 0;
    }
    public ArrayList<transp> getTrans() {
        String sql = "select * from transport";
        String url = "jdbc:postgresql://localhost:5432/fd";
        String username = "postgres";
        String password = "123456";
        ArrayList<transp> list = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                transp model = new transp(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
                list.add(model);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;

    }
    
    public int deletetrans(String tName) {
        String sql = "delete from transport where name=?";
        String url = "jdbc:postgresql://localhost:5432/fd";
        String username = "postgres";
        String password = "123456";
        int row = 0;
        try {
            Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, tName);
            row = pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }
    
}
